import React from 'react'

export default function HeaderBurger() {
  return (
    <div>
      
    </div>
  )
}
