import React from 'react'
import Top from './components/Top/Top'
import Slider2 from './components/Slider/Slider'
export default function Home() {
  return (
    <div>
      <Top/>
      <Slider2/>
    </div>
  )
}
