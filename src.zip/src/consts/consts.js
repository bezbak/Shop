import iphone1 from '../assets/images/iphone-14-1.png'
import iphone2 from '../assets/images/iphone-14-2.png'
import iphone3 from '../assets/images/iphone-14-pro-3.png'
import iphone4 from '../assets/images/iphone-14-pro-4.png'

export const slider_1 = [
    {
        name:"iPhone 14 Pro",
        price: "1200$",
        som_price:"120 000 сом",
        img:iphone1,
        id:1
    },
    {
        name:"iPhone 14 Pro Max",
        price: "1200$",
        som_price:"120 000 сом",
        img:iphone2,
        id:2
    },
    {
        name:"iPhone 14 Plus",
        price: "1200$",
        som_price:"120 000 сом",
        img:iphone3,
        id:3
    },
    {
        name:"iPhone 14",
        price: "1200$",
        som_price:"120 000 сом",
        img:iphone4,
        id:4
    },
]